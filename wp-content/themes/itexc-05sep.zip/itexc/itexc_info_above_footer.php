<?php
/* 
 *Link above footer "Get in touch"
 */
?>
<div class="container-fluid wp_margin-abovefooter" id="getInTouch">
    <div class="container getintouch">
        <?php 
         echo itexc_of_get_option('text_above_footer');    
        ?>
        
    </div>
    <div class="clearFixHome">
    </div>
</div>

